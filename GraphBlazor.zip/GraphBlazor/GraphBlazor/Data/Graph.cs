﻿using Syncfusion.Blazor.Charts.Chart.Internal;
using Syncfusion.Blazor.PivotView;

namespace GraphBlazor.Data
{


    /// Classe permettant de créer un objet (pour une certaine abscisse) comportant les coordonnées des points des fonctions cosinus et sinus
    public class ChartData
    {
        public double xCos { get; set; }
        public double yCos { get; set; }
        public double xSin { get; set; }
        public double ySin { get; set; }
    }

    /// Classe permettant de retourner via la méthode Courbes() une liste d'objets "ChartData" formant les courbes des fonctions cosinus et sinus
    public class Courbes
    {

        public List<ChartData> CreateCourbes()
        {
            /// On initialise la liste des objets "ChartData"
            List<ChartData> chartData = new List<ChartData>();

            /// Afin d'obtenir des courbes suffisamment précises (comprises entre 0° et 360°), on crée des objets "ChartData" tous les π/64 radians
            /// sur l'axe des abscisses, soit environ tous les 2.8 degrés, en les rajoutant un à un à la liste chartData
            for (double i = 0; i < (2 * Math.PI); i = (i + Math.PI / 64))
            {
                ChartData point = new ChartData { xCos = i * (180/Math.PI), yCos = Math.Cos(i), xSin = i * (180 / Math.PI), ySin = Math.Sin(i) };
                chartData.Add(point);
            }

            return chartData;
        }

    }
}