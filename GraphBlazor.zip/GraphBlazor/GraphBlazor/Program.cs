using GraphBlazor.Data;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Syncfusion.Blazor;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddSingleton<WeatherForecastService>();
builder.Services.AddSyncfusionBlazor();

var app = builder.Build();

Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("Mgo+DSMBaFt/QHNqVVhmXVpFdEBBXHxAd1p/VWJYdVt5flBPcDwsT3RfQF9iS3xSdkJjX3xccXNcQQ==;Mgo+DSMBPh8sVXJ0S0V+XE9Cd1RDX3xKf0x/TGpQb19xflBPallYVBYiSV9jS3xSdEdiWXhedndXR2leWQ==;ORg4AjUWIQA/Gnt2VVhjQlFacF5JXGFWfVJpTGpQdk5xdV9DaVZUTWY/P1ZhSXxRd0dhWH9ZcHJWRGJcVEM=;Nzg0NDI5QDMyMzAyZTMzMmUzMGNZWk9JWmJRT0srMksrTHVWcWRSWjVTRXRTSHdPUUZHeGpHVUdHR2lZOEU9;Nzg0NDMwQDMyMzAyZTMzMmUzMGRIMi9peFI5Y1JJWlVnZURWcko3RjJreGNEODE3Z3Y3Yk4rRExjcWk4Rzg9;NRAiBiAaIQQuGjN/V0Z+X09EaFlDVmJLYVB3WmpQdldgdVRMZVVbQX9PIiBoS35RdERhW35ed3RTRWJeVkxx;Nzg0NDMyQDMyMzAyZTMzMmUzMEsxd25xMU1QdU1rZnBrY2w3Y1Y3bENFeTluSnh1TmgwZGhCR0ZadUVadkE9;Nzg0NDMzQDMyMzAyZTMzMmUzMElncjROS2hyb3R5MHRkWnFSVitSanJrclFuMGtoOWxNYVZTWjkzSFJwTm89;Mgo+DSMBMAY9C3t2VVhjQlFacF5JXGFWfVJpTGpQdk5xdV9DaVZUTWY/P1ZhSXxRd0dhWH9ZcHJWRGNZVkM=;Nzg0NDM1QDMyMzAyZTMzMmUzMGluYnBob1FjUkRtblVWUU0yYy9DYVhTR2FZS2FMTDNGRk5wZFhVQVlPNGc9;Nzg0NDM2QDMyMzAyZTMzMmUzMElUYldOdEFzSldKeXhMWFdTczFPNFY4Z05kN0thckVoSE0zYmZsVElMakU9;Nzg0NDM3QDMyMzAyZTMzMmUzMEsxd25xMU1QdU1rZnBrY2w3Y1Y3bENFeTluSnh1TmgwZGhCR0ZadUVadkE9");
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
